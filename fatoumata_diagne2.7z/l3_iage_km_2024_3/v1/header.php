
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Produits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<nav class="nav navbar-primary bg-black col-4 mx-auto ">
<a class="nav-item nav-link text-white fw-4 text-center fw-4" href="?controller=utilisateur">Utilisateurs</a>
<a class="nav-item nav-link text-white fw-4 text-center fw-4" href="?controller=produit">Produits</a>
<a class="nav-item nav-link text-white fw-4 text-center fw-4" href="?controller=categorie">Categories</a>
</nav>